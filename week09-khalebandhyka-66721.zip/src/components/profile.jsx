import React from "react";

function Profile(props) {
  return <img className="circle-img" src={props.img} alt="profile_img" />;
}

export default Profile;
